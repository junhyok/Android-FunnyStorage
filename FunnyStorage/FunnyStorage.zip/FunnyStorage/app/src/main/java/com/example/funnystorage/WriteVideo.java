package com.example.funnystorage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import java.util.ArrayList;

public class WriteVideo extends AppCompatActivity {
    private EditText editText_write_content_title, editText_video_image_url, editText_content_url;
    private Button button_write_finish;
    private RadioButton radioButton_video, radioButton_image;
    private RadioGroup radioContentSelect;
    private View textView_video_thumbnail, textView_content_url;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_video);
        editText_write_content_title = (EditText) findViewById(R.id.editText_content_title);
        editText_video_image_url = (EditText) findViewById(R.id.editText_video_image_url);
        editText_content_url = (EditText) findViewById(R.id.editText_content_url);
        textView_video_thumbnail = findViewById(R.id.textView_video_thumbnail);
        textView_content_url = findViewById(R.id.textView_content_url);
        radioButton_image = findViewById(R.id.radioButton_image);
        radioButton_video = findViewById(R.id.radioButton_video);
        radioContentSelect = findViewById(R.id.radioContentSelect);
        button_write_finish = findViewById(R.id.button_write_finish);
        // editText_write_content_title
        initIntent();

        radioContentSelect.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int i) {
                if (i == R.id.radioButton_video) {
                    editText_content_url.setVisibility(View.VISIBLE);
                    textView_content_url.setVisibility(View.VISIBLE);
                    editText_video_image_url.setVisibility(View.VISIBLE);
                    textView_video_thumbnail.setVisibility(View.VISIBLE);
                    button_write_finish.setVisibility(View.VISIBLE);
                    button_write_finish.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //화면전환 (intent 객체 생성)
                            Intent i = new Intent(WriteVideo.this, FunnyVideo.class);

                            //입력된 데이터 받기 - EditText의 text를 저장
                            String video_title = editText_write_content_title.getText().toString();
                            //String video_title_url = editText_video_url.getText().toString();

                            //Intent를 통하여 전달하는 방식 - EnterVideo로 전달할 인텐트 생성
                            i.putExtra("video_title", video_title);
                            //i.putExtra("video)title_url",video_title_url);

                            //보내는 Activity 시작
                            startActivity(i);
                        }
                    });
                } else if (i == R.id.radioButton_image) {
                    editText_video_image_url.setVisibility(View.GONE);
                    textView_video_thumbnail.setVisibility(View.GONE);
                    editText_content_url.setVisibility(View.VISIBLE);
                    textView_content_url.setVisibility(View.VISIBLE);
                    button_write_finish.setVisibility(View.VISIBLE);
                    button_write_finish.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            //화면전환 (intent 객체 생성)
                            Intent i_funnyStory = new Intent(WriteVideo.this, FunnyStory.class);
                            Intent i_enterStory = new Intent(WriteVideo.this, FunnyStory.class);

                            //입력된 데이터 받기 - EditText의 text를 저장
                            String image_title_funnyStory = editText_write_content_title.getText().toString();
                            String image_title_enterStory = editText_write_content_title.getText().toString();
                            //Intent를 통하여 전달하는 방식 - EnterVideo로 전달할 인텐트 생성
                            i_funnyStory.putExtra("image_title", image_title_funnyStory);
                            i_enterStory.putExtra("image_title", image_title_enterStory);

                            //보내는 Activity 시작
                            startActivity(i_funnyStory);
                            startActivity(i_enterStory);
                        }
                    });
                }
            }
        });
        /*button_write_finish.setOnClickListener(new View.OnClickListener() {
             @Override
              public void onClick(View v) {

                 //화면전환 (intent 객체 생성)
                 Intent i=new Intent(WriteVideo.this, FunnyVideo.class);

                //입력된 데이터 받기 - EditText의 text를 저장
                 String video_title = editText_write_video_title.getText().toString();
                 //String video_title_url = editText_video_url.getText().toString();

                 //Intent를 통하여 전달하는 방식 - EnterVideo로 전달할 인텐트 생성
                i.putExtra("video_title",video_title);
                //i.putExtra("video)title_url",video_title_url);

                //보내는 Activity 시작
                startActivity(i);
            }
        });*/
    }

    //웃긴동영상 모음 화면으로 전환
    public void clickMethod_video_list(View view) {
        Intent intent = new Intent(getApplicationContext(), FunnyVideo.class);
        startActivity(intent);
    }

    //URL 받는 함수
    private void initIntent() {

        // 인텐트를 얻어오고, 액션과 MIME 타입을 가져온다
        Intent intent = getIntent();
        String action = intent.getAction();
        String type = intent.getType();

        // 인텐트 정보가 있는 경우 실행
        if (Intent.ACTION_SEND.equals(action) && type != null) {
            if ("text/plain".equals(type)) {

                // 가져온 인텐트의 텍스트 정보
                String sharedText = intent.getStringExtra(Intent.EXTRA_TEXT);

                // TODO : 위에 받아온 텍스트로 원하는 기능 구현
                editText_content_url.setText(sharedText);
            } else if (type.startsWith("image/")) {
                Uri imageUri = (Uri) intent.getParcelableExtra(Intent.EXTRA_STREAM);
                editText_content_url.setText((CharSequence) imageUri);
            } else if (Intent.ACTION_SEND_MULTIPLE.equals(action) && type != null) {
                if (type.startsWith("image/")) {
                    ArrayList<Uri> imageUris = intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM);
                    editText_content_url.setText((CharSequence) imageUris);
                }
            }
        }
    }
}
