package com.example.funnystorage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class EnterVideo extends AppCompatActivity {
    private EnterVideo toolbar_video;
    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_video);
        Button button_share_video = (Button) findViewById(R.id.button_share_video);
        button_share_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.putExtra(Intent.EXTRA_TITLE,"웃긴모음 저장소");
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "앱을 선택해 주세요"));

            }
        });
    }
    //화살표 이미지를 누르면 FunnyVideo로 화면 전환
    public void clickMethod_video_list(View view) {
        Intent intent = new Intent(getApplicationContext(),FunnyVideo.class);
        startActivity(intent);
    }
}

    /*
    //toolbar 관련
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.enter_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.enter_edit:
                Intent intent = new Intent(getApplicationContext(),WriteVideo.class);
                startActivity(intent);
                //내용 수정하기
                break;
           }
        return super.onOptionsItemSelected(item);
    }
    */

