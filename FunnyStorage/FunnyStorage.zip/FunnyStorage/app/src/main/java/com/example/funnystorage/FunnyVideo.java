package com.example.funnystorage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FunnyVideo extends AppCompatActivity {
    private  TextView text_title;

    /*@Override
    protected void onPause() {
        super.onPause();
        finish();
    }*/
/*
    //onResume은 onPause에서 sharedpreferences에 임시저장된 데이터를 불러오는데 주로 사용
    @Override
    protected void onResume() {
        super.onResume();
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funny_video);
        text_title = (TextView)findViewById(R.id.textView_video_title);

        Intent intent = getIntent();

        String video_title=intent.getStringExtra("video_title");

        text_title.setText(video_title);
        //FunnyStory로 화면전환
        Button moveButton_funny_story = (Button) findViewById(R.id.button_move_story);
        moveButton_funny_story.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), FunnyStory.class);
                startActivity(intent);
            }
        });

        //WirteVideo로 화면전환
        Button moveButton_write_video = (Button) findViewById(R.id.button_move_write_video);
        moveButton_write_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), WriteVideo.class);
                startActivity(intent);
            }
        });
    }
    //EnterVideo로 화면전환
    public void clickMethod_video(View view) {
        Intent intent = new Intent(getApplicationContext(), EnterVideo.class);
        startActivity(intent);
    }

    //toolbar 관련
   /* @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.content_add:
                Intent intent = new Intent(getApplicationContext(),WriteVideo.class);
                startActivity(intent);
                //비디오 작성창 선택
                break;
            case R.id.content_delete:
                //내용 삭제
                break;
             }
        return super.onOptionsItemSelected(item);
    }*/
}




/*@Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funny_video);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar_main_menu);
        toolbar.setNavigationIcon(R.drawable.menu);
        setSupportActionBar(toolbar);

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch (item.getItemId()){
            case R.id.content_add :
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }
    ActionBar icon_menu = getSupportActionBar();
    icon_menu.setIcon(R.drawable.menu);
    icon_menu.setDisplayUseLogoEnabled(true);
    icon_menu.setDisplayShowHomeEnabled(true)*/










