package com.example.funnystorage;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class FunnyStory extends AppCompatActivity {
    private TextView text_title;

    /* @Override
    protected void onPause() {
        super.onPause();
        finish();
    }*/
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_funny_story);
        //텍스트뷰 제목 인텐트 받아서 데이터 올리기
        text_title = (TextView) findViewById(R.id.textView_story_title);

        Intent intent = getIntent();

        String image_title = intent.getStringExtra("image_title");

        text_title.setText(image_title);
//FunnyVideo로 화면전환
        Button imageButton = (Button) findViewById(R.id.button_move_video);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), FunnyVideo.class);
                startActivity(intent);
            }
        });
        //WirteStory로 화면전환
        Button moveButton_write_video = (Button) findViewById(R.id.button_move_write_story);
        moveButton_write_video.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), WriteVideo.class);
                startActivity(intent);
            }
        });
/*
        //WriteStory에서 제목 받아오기
        Intent intent = getIntent() ;
        TextView textViewTitle = (TextView) findViewById(R.id.textView_story_title1) ;
        String name = intent.getStringExtra("story_title") ;
        if (name != null)
            textViewTitle.setText(name) ;

 */
    }
    //EnterStory로 화면전환
    public void clickMethod_story(View view) {
        Intent intent = new Intent(getApplicationContext(), EnterStory.class);
        startActivity(intent);

    }
}
    /*
    //toolbar 관련
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.content_add:
                Intent intent = new Intent(getApplicationContext(),WriteStory.class);
                startActivity(intent);
                //비디오 작성창 선택
                break;
            case R.id.content_delete:
                //내용 삭제
                break;
        }
        return super.onOptionsItemSelected(item);
    }*/



