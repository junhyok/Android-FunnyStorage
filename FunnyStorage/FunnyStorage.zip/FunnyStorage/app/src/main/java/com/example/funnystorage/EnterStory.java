package com.example.funnystorage;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class EnterStory extends AppCompatActivity {
    private  TextView textview_story_title;

    @Override
    protected void onPause() {
        super.onPause();
        finish();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enter_story);
        //텍스트뷰 제목 인텐트 받아서 데이터 올리기
        textview_story_title = (TextView)findViewById(R.id.textView_story_title);

        Intent intent = getIntent();

        String image_title_enterStory=intent.getStringExtra("image_title");

        textview_story_title.setText(image_title_enterStory);

        Button button_share_image = (Button) findViewById(R.id.button_share_image);
        button_share_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.addCategory(Intent.CATEGORY_DEFAULT);
                intent.putExtra(Intent.EXTRA_TITLE,"웃긴모음 저장소");
                intent.setType("text/plain");
                startActivity(Intent.createChooser(intent, "앱을 선택해 주세요"));
            }
        });
    }
 //화살표 이미지를 누르면 FunnyStory로 화면 전환
    public void clickMethod_story_list(View view) {
        Intent intent = new Intent(getApplicationContext(),FunnyStory.class);
        startActivity(intent);
    }
}
/*
    //toolbar 관련
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.enter_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.enter_edit:
                Intent intent = new Intent(getApplicationContext(),WriteStory.class);
                startActivity(intent);
                //내용 수정하기
                break;
        }
        return super.onOptionsItemSelected(item);
    }*/

